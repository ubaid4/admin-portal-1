declare module '@dashboardcode/bsmultiselect'{
    // example
    export function ModuleFactory(environment:any): any
    //export declare type ModuleFactory = (environment: any) => any;
}


//export * from './src';