export function CreateElementAspect(createElement, createElementFromHtml, createElementFromHtmlPutAfter){
    return {
        createElement,
        createElementFromHtml,
        createElementFromHtmlPutAfter
    }
}