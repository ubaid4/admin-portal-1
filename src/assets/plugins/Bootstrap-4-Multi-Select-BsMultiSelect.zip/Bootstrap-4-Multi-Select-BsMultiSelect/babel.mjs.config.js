module.exports = {
    //retainLines: true,
    // "presets": [
    //     [
    //         "@babel/preset-env",
    //         {
    //             "loose": false, // ES6 to ES5
    //             "bugfixes": true,
    //             // "useBuiltIns": "usage",
    //             "modules": false,
    //             "exclude": ["transform-typeof-symbol"],
    //             // "targets": {
    //             //     "browsers": [
    //             //         // browsers that can load ESM bundles: https://caniuse.com/es6-module
    //             //         "chrome  >= 61", "Firefox >= 60", "edge >= 16", "iOS >= 10.3","Safari >= 10.1","Android >= 93","Opera >= 48"]
    //             // },
    //             "debug": true
    //         }
    //     ]
    // ]
}