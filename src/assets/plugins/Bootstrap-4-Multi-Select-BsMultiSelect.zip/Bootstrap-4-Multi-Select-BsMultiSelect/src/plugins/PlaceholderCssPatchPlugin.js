export function PlaceholderCssPatchPlugin(defaults){
    defaults.cssPatch.filterInput_empty = 'form-control'
}