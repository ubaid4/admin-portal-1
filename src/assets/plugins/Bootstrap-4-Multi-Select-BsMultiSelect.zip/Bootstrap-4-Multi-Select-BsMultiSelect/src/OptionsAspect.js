// export function OptionsAspect(options){
//     return {
//         getOptions : () => options
//     }
// }
