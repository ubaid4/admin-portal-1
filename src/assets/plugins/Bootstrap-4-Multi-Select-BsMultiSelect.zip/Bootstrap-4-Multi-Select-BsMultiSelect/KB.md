# RTL
https://www.rtlstyling.com/posts/rtl-styling/ (RU: https://habr.com/ru/post/484886/ )

# NPM

npm publish --tag beta


# NPM update
npm outdated -g
npm update -g

# Git
"please check out a branch to push to a remote"
git branch -r   // list all remote branches
git branch --show-current // get current branch