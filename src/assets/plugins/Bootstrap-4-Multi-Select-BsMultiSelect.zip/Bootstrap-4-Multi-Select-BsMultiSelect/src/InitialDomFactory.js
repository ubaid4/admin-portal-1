// export function InitialDomFactory(initialElement){
//     return {
        
//     }
// }