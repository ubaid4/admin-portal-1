export function WarningCssPatchPlugin(defaults){
    defaults.cssPatch.warning = {paddingLeft: '.25rem', paddingRight: '.25rem', zIndex: 4,  fontSize:'small', backgroundColor: 'var(--bs-warning)'}
}